# Noctis Pulse

Client-side cinematic visual mod for Minecraft Java 1.21.11 + Fabric.

## Build
Install JDK 21 and a current Gradle wrapper, then run:

`gradle build`

The remapped jar is produced in `build/libs/`.

## Install
Install Fabric Loader for Minecraft 1.21.11, install Fabric API, then place the built jar in the Minecraft `mods` folder.

Press **O** in-game to open Noctis Pulse settings.

## Architecture
- `config`: persistent JSON configuration and quality scaling.
- `effect`: lifetime-managed ghosts, combat pulses, movement echoes, HUD pulses, rare ambient anomalies.
- `ui`: compact client configuration screen.
- `mixin`: render-tick integration for damage feedback.

### Important target-version note
Minecraft/Fabric rendering APIs are version-sensitive. The build uses the official 1.21.11 mappings and Fabric API version published in the 1.21.11 Fabric reference material. If Fabric changes an event signature in a newer 1.21.11 API build, refresh dependencies and adjust only that hook rather than the effect architecture.
