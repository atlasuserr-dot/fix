package dev.noctis.pulse.mixin;

import dev.noctis.pulse.NoctisPulseClient;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
 @Inject(method="tick",at=@At("TAIL"))
 private void noctis$visualCombatProbe(CallbackInfo ci){
   Minecraft mc=Minecraft.getInstance();
   if(mc.player==null||!NoctisPulseClient.CONFIG.enabled)return;
   if(mc.player.hurtTime==9) NoctisPulseClient.EFFECTS.hurt(mc.player.position());
 }
}