package dev.noctis.pulse.ui;

import dev.noctis.pulse.NoctisPulseClient;
import dev.noctis.pulse.config.PulseConfig;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public final class PulseScreen extends Screen {
 private final Screen parent;
 public PulseScreen(Screen parent){super(Component.literal("NOCTIS PULSE"));this.parent=parent;}
 protected void init(){
   int x=width/2-120,y=height/2-90;
   addRenderableWidget(Button.builder(label("Master: "+NoctisPulseClient.CONFIG.enabled),b->{NoctisPulseClient.CONFIG.enabled=!NoctisPulseClient.CONFIG.enabled;reload();}).bounds(x,y,240,20).build());
   addRenderableWidget(Button.builder(label("Ghosts: "+NoctisPulseClient.CONFIG.ghosts),b->{NoctisPulseClient.CONFIG.ghosts=!NoctisPulseClient.CONFIG.ghosts;reload();}).bounds(x,y+24,240,20).build());
   addRenderableWidget(Button.builder(label("Combat: "+NoctisPulseClient.CONFIG.combatEffects),b->{NoctisPulseClient.CONFIG.combatEffects=!NoctisPulseClient.CONFIG.combatEffects;reload();}).bounds(x,y+48,240,20).build());
   addRenderableWidget(Button.builder(label("Movement: "+NoctisPulseClient.CONFIG.movementEffects),b->{NoctisPulseClient.CONFIG.movementEffects=!NoctisPulseClient.CONFIG.movementEffects;reload();}).bounds(x,y+72,240,20).build());
   addRenderableWidget(Button.builder(label("Screen FX: "+NoctisPulseClient.CONFIG.screenEffects),b->{NoctisPulseClient.CONFIG.screenEffects=!NoctisPulseClient.CONFIG.screenEffects;reload();}).bounds(x,y+96,240,20).build());
   addRenderableWidget(Button.builder(label("Quality: "+NoctisPulseClient.CONFIG.quality),b->{NoctisPulseClient.CONFIG.quality=PulseConfig.Quality.values()[(NoctisPulseClient.CONFIG.quality.ordinal()+1)%3];reload();}).bounds(x,y+120,240,20).build());
   addRenderableWidget(Button.builder(Component.literal("Done"),b->{NoctisPulseClient.CONFIG.save();onClose();}).bounds(x,y+150,240,20).build());
 }
 private Component label(String s){return Component.literal(s);}
 private void reload(){clearWidgets();init();}
 public void render(GuiGraphics g,int mx,int my,float d){renderBackground(g,mx,my,d);g.fill(width/2-136,height/2-106,width/2+136,height/2+190,0xE611081C);g.drawCenteredString(font,title,width/2,height/2-96,0xD9B7FF);super.render(g,mx,my,d);}
 public void onClose(){minecraft.setScreen(parent);}
}