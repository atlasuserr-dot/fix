package dev.noctis.pulse.effect;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.noctis.pulse.NoctisPulseClient;
import dev.noctis.pulse.config.PulseConfig;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.phys.Vec3;
import java.util.*;

public final class PulseEffects {
    private final Deque<Ghost> ghosts=new ArrayDeque<>();
    private float combatPulse, damagePulse, ambientPulse;
    private long ticks;

    public void tick(Minecraft mc) {
        ticks++;
        ghosts.removeIf(g -> ++g.age > g.life);
        combatPulse*=.84f; damagePulse*=.88f; ambientPulse*=.94f;
        if (mc.player!=null && NoctisPulseClient.CONFIG.movementEffects && mc.player.getDeltaMovement().horizontalDistanceSqr()>.015)
            if(ticks%5==0) spawnGhost(mc.player.position(), Ghost.Kind.MOTION);
    }
    public void hit(Vec3 pos, boolean critical) {
        combatPulse=Math.max(combatPulse,critical?1f:.65f);
        spawnGhost(pos,critical?Ghost.Kind.CRITICAL:Ghost.Kind.HIT);
    }
    public void hurt(Vec3 pos) { damagePulse=1f; spawnGhost(pos,Ghost.Kind.DAMAGE); }
    public void ambient(Vec3 pos) { ambientPulse=.35f; spawnGhost(pos,Ghost.Kind.AMBIENT); }
    private void spawnGhost(Vec3 pos,Ghost.Kind kind) {
        PulseConfig c=NoctisPulseClient.CONFIG; if(!c.enabled||!c.ghosts)return;
        while(ghosts.size()>=c.ghostLimit())ghosts.removeFirst();
        ghosts.addLast(new Ghost(pos,kind,Math.max(4,(int)(c.ghostLifetime*20)),c.ghostOpacity));
    }
    public void renderWorld(WorldRenderContext ctx) {
        // Ghosts are rendered as translucent world-space energy motes rather than cloned entities:
        // this keeps the effect client-side, cheap, and avoids entity duplication.
        var mc=Minecraft.getInstance(); if(mc.level==null||!NoctisPulseClient.CONFIG.enabled)return;
        for(Ghost g:ghosts) {
            float t=g.alpha();
            if(t<=0)continue;
            int count=g.kind==Ghost.Kind.CRITICAL?10:4;
            for(int i=0;i<count;i++){
                double a=(ticks*.07+i*2.399);
                double r=(1-t)*(.18+i*.015);
                mc.level.addParticle(net.minecraft.core.particles.ParticleTypes.END_ROD,
                    g.pos.x+Math.cos(a)*r,g.pos.y+.2+i*.035,g.pos.z+Math.sin(a)*r,
                    0, .002*(1-t), 0);
            }
        }
    }
    public void renderHud(GuiGraphics g,float dt,PulseConfig c) {
        if(!c.enabled||!c.screenEffects)return;
        int w=g.guiWidth(),h=g.guiHeight();
        float p=Math.max(combatPulse,Math.max(damagePulse,ambientPulse))*c.intensity;
        if(p>.01f){
            int a=(int)(Math.min(90,p*70));
            g.fill(0,0,w,3, (a<<24)|0x5B0C85);
            g.fill(0,h-3,w,h,(a<<24)|0x5B0C85);
            g.fill(0,0,3,h,(a/2<<24)|0x120019);
            g.fill(w-3,0,w,h,(a/2<<24)|0x120019);
        }
    }
    private static final class Ghost {
        enum Kind{HIT,CRITICAL,MOTION,DAMAGE,AMBIENT}
        final Vec3 pos; final Kind kind; final int life; final float opacity; int age;
        Ghost(Vec3 p,Kind k,int l,float o){pos=p;kind=k;life=l;opacity=o;}
        float alpha(){float x=1f-age/(float)life; return x*x*opacity;}
    }
}