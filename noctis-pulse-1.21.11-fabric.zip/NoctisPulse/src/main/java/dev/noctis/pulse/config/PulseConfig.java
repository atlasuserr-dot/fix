package dev.noctis.pulse.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import dev.noctis.pulse.NoctisPulseClient;
import net.fabricmc.loader.api.FabricLoader;
import java.nio.file.*;

public final class PulseConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("noctis-pulse.json");
    public enum Quality { HIGH, BALANCED, PERFORMANCE }
    public Quality quality = Quality.BALANCED;
    public boolean enabled=true, ghosts=true, combatEffects=true, movementEffects=true, inventoryEffects=true, screenEffects=true, ambientEffects=true;
    public float intensity=1f, ghostOpacity=.55f, ghostLifetime=.42f;
    public boolean capeGlow=true, animatedCape=true;
    public int maxGhosts=36;
    public static PulseConfig load() {
        try { if (Files.exists(FILE)) return GSON.fromJson(Files.readString(FILE), PulseConfig.class); }
        catch (Exception ignored) {}
        PulseConfig c=new PulseConfig(); c.save(); return c;
    }
    public void save() {
        try { Files.createDirectories(FILE.getParent()); Files.writeString(FILE,GSON.toJson(this)); }
        catch(Exception ignored){}
    }
    public int ghostLimit() { return switch(quality){case HIGH->maxGhosts; case BALANCED->Math.min(maxGhosts,24); case PERFORMANCE->Math.min(maxGhosts,10);}; }
    public float scale() { return switch(quality){case HIGH->1f;case BALANCED->.72f;case PERFORMANCE->.42f;};}
}