package dev.noctis.pulse;

import dev.noctis.pulse.config.PulseConfig;
import dev.noctis.pulse.effect.*;
import dev.noctis.pulse.ui.PulseScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import org.lwjgl.glfw.GLFW;

public final class NoctisPulseClient implements ClientModInitializer {
    public static final PulseConfig CONFIG = PulseConfig.load();
    public static final PulseEffects EFFECTS = new PulseEffects();
    private static KeyMapping menuKey;

    @Override public void onInitializeClient() {
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
            "key.noctispulse.menu", GLFW.GLFW_KEY_O, "category.noctispulse"));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (menuKey.consumeClick()) client.setScreen(new PulseScreen(client.screen));
            EFFECTS.tick(client);
            if (CONFIG.ambientEffects && client.level != null && client.player != null)
                AmbientDirector.tick(client, EFFECTS, CONFIG);
        });
        WorldRenderEvents.AFTER_ENTITIES.register(ctx -> EFFECTS.renderWorld(ctx));
        HudRenderCallback.EVENT.register((graphics, tickDelta) -> EFFECTS.renderHud(graphics, tickDelta, CONFIG));
    }
}