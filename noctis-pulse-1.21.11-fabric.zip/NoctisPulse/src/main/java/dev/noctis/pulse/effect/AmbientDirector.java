package dev.noctis.pulse.effect;
import dev.noctis.pulse.config.PulseConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.util.RandomSource;
import net.minecraft.world.phys.Vec3;

public final class AmbientDirector {
 private static long next=0;
 public static void tick(Minecraft mc,PulseEffects fx,PulseConfig c){
   long now=mc.level.getGameTime(); if(now<next)return;
   RandomSource r=mc.level.random;
   if(r.nextInt(c.quality==PulseConfig.Quality.HIGH?900:1800)==0){
     Vec3 look=mc.player.getLookAngle(); Vec3 side=new Vec3(-look.z,0,look.x).normalize();
     Vec3 p=mc.player.position().add(side.scale(r.nextBoolean()?7:-7)).add(look.scale(10+r.nextInt(8)));
     fx.ambient(p); next=now+300+r.nextInt(900);
   }
 }
}